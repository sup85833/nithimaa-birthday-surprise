NITHIMAA BIRTHDAY WEBSITE

Contents:
- index.html: responsive birthday site
- assets/photo1.jpg through photo12.jpg: your 12 photos
- assets/our-song.mp3: audio extracted from your uploaded WhatsApp video

To preview: open index.html in a modern browser. The love note, photo lightbox, wish animation, and music button are wired up.
To deploy on Vercel: extract this folder, then import/upload the folder as a new project (static site; no build command required). Make sure index.html and the assets folder are at the project root.
